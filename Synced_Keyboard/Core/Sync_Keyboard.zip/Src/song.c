#include "song.h"

/* ── Into Sandy's City — Bobby Prince (Doom II MAP09) ──────────
 * Main melody transcribed for single-voice playback.
 * Durations in ms at approx original tempo (~140 BPM).
 * 1 beat = ~428ms, eighth note = ~214ms, sixteenth = ~107ms.
 * REST = 0.0f frequency.                                        */

/* Riff A — opening lead phrase */
const NoteEvent riffA[] = {
    { 659.26f, 107 },   /* E5  */
    { 659.26f, 107 },   /* E5  */
    { 659.26f, 107 },   /* E5  */
    { 783.99f, 107 },   /* G5  */
    { 659.26f, 214 },   /* E5  */
    { 587.33f, 107 },   /* D5  */
    { 659.26f, 214 },   /* E5  */
    {   0.00f, 107 },   /* REST */

    { 440.00f, 107 },   /* A4  */
    { 440.00f, 107 },   /* A4  */
    { 440.00f, 107 },   /* A4  */
    { 523.25f, 107 },   /* C5  */
    { 440.00f, 214 },   /* A4  */
    { 392.00f, 107 },   /* G4  */
    { 440.00f, 214 },   /* A4  */
    {   0.00f, 107 },   /* REST */

    NOTE_END
};

/* Riff B — second phrase / variation */
const NoteEvent riffB[] = {
    { 659.26f, 107 },   /* E5  */
    { 698.46f, 107 },   /* F5  */
    { 659.26f, 107 },   /* E5  */
    { 622.25f, 107 },   /* D#5 */
    { 659.26f, 214 },   /* E5  */
    {   0.00f, 107 },   /* REST */
    { 587.33f, 107 },   /* D5  */
    { 554.37f, 107 },   /* C#5 */
    { 523.25f, 214 },   /* C5  */
    {   0.00f, 107 },   /* REST */

    { 493.88f, 107 },   /* B4  */
    { 523.25f, 107 },   /* C5  */
    { 493.88f, 107 },   /* B4  */
    { 466.16f, 107 },   /* A#4 */
    { 493.88f, 214 },   /* B4  */
    {   0.00f, 107 },   /* REST */
    { 440.00f, 107 },   /* A4  */
    { 415.30f, 107 },   /* G#4 */
    { 392.00f, 214 },   /* G4  */
    {   0.00f, 107 },   /* REST */

    NOTE_END
};
