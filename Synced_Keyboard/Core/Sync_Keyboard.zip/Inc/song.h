#ifndef SONG_H
#define SONG_H

#include <stdint.h>

/* A single note event: frequency in Hz, duration in ms.
 * frequency = 0.0f means REST (silence for that duration). */
typedef struct {
    float    frequency;
    uint16_t duration_ms;
} NoteEvent;

/* Sentinel to mark end of a sequence */
#define NOTE_END  { 0.0f, 0 }

extern const NoteEvent riffA[];
extern const NoteEvent riffB[];

#endif /* SONG_H */
